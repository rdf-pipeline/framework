This "node" directory contains updaters (or in some cases, static 
content, if a node has no updater) for the nodes in an RDF Pipeline.
It must also contain the pipeline definition, "pipeline.ttl".

