This "ont" directory contains the ontology/rules used by the
RDF Pipeline framework.  Its content should not be modified
except to add a "local.n3" ontology/rules containing local
additions.

