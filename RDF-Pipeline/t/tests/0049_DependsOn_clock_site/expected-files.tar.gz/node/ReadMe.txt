Cause the updater to be fired on every request, because
the node dependsOn a clock page.

